/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Asesor {
     private String cedula_asesor;
    private String nombre_asesor;
    private String apellido_asesor;
    private String telefono_asesor;
    private String email_asesor;
    private String ciudad_asesor;
    private String area_asesor;
    private List <Asesor> lista_asesores;

    public String getCedula_asesor() {
        return cedula_asesor;
    }

    public void setCedula_asesor(String cedula_asesor) {
        this.cedula_asesor = cedula_asesor;
    }

    public String getNombre_asesor() {
        return nombre_asesor;
    }

    public void setNombre_asesor(String nombre_asesor) {
        this.nombre_asesor = nombre_asesor;
    }

    public String getApellido_asesor() {
        return apellido_asesor;
    }

    public void setApellido_asesor(String apellido_asesor) {
        this.apellido_asesor = apellido_asesor;
    }

    public String getTelefono_asesor() {
        return telefono_asesor;
    }

    public void setTelefono_asesor(String telefono_asesor) {
        this.telefono_asesor = telefono_asesor;
    }

    public String getEmail_asesor() {
        return email_asesor;
    }

    public void setEmail_asesor(String email_asesor) {
        this.email_asesor = email_asesor;
    }

    public String getCiudad_asesor() {
        return ciudad_asesor;
    }

    public void setCiudad_asesor(String ciudad_asesor) {
        this.ciudad_asesor = ciudad_asesor;
    }

    public String getArea_asesor() {
        return area_asesor;
    }

    public void setArea_asesor(String area_asesor) {
        this.area_asesor = area_asesor;
    }

    public List<Asesor> getLista_asesores() {
        return lista_asesores;
    }

    public void setLista_asesores(List<Asesor> lista_asesores) {
        this.lista_asesores = lista_asesores;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.cedula_asesor + "\n" + this.apellido_asesor + 
                "\n" + this.nombre_asesor + "\n" + this.telefono_asesor + "\n" + this.email_asesor + "\n" + this.ciudad_asesor +
                "\n" + this.area_asesor ;
        return retorno;
    }
    
}
