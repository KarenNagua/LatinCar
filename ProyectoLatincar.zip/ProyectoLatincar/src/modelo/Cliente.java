/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Cliente {
     private String cedula_cliente;
    private String nombre_cliente;
    private String apellido_cliente;
    private String telefono_cliente;
    private String email_cliente;
    private String ciudad_cliente;
    private String area_cliente;
    private List <Cliente> lista_clientes;
    
    

    public String getCedula_cliente() {
        return cedula_cliente;
    }

    public void setCedula_cliente(String cedula_cliente) {
        this.cedula_cliente = cedula_cliente;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public String getApellido_cliente() {
        return apellido_cliente;
    }

    public void setApellido_cliente(String apellido_cliente) {
        this.apellido_cliente = apellido_cliente;
    }

    public String getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(String telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public String getEmail_cliente() {
        return email_cliente;
    }

    public void setEmail_cliente(String email_cliente) {
        this.email_cliente = email_cliente;
    }

    public String getCiudad_cliente() {
        return ciudad_cliente;
    }

    public void setCiudad_cliente(String ciudad_cliente) {
        this.ciudad_cliente = ciudad_cliente;
    }

    public String getArea_cliente() {
        return area_cliente;
    }

    public void setArea_cliente(String area_cliente) {
        this.area_cliente = area_cliente;
    }

    public List<Cliente> getLista_clientes() {
        return lista_clientes;
    }

    public void setLista_clientes(List<Cliente> lista_clientes) {
        this.lista_clientes = lista_clientes;
    }


    
    

    
    
     public String toString(){
        
        String retorno = "";
        retorno = retorno + this.cedula_cliente + "\n" + this.apellido_cliente+ 
                "\n" + this.nombre_cliente + "\n" + this.telefono_cliente + "\n" + this.email_cliente + "\n" + this.ciudad_cliente +
                "\n" + this.area_cliente ;
        return retorno;
    }

    
    
}
