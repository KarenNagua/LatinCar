/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import modelo.Cliente;


/**
 *
 * @author Juan Diego
 */
public class TablaCliente extends AbstractTableModel {

    private List<Cliente> lista = new ArrayList<Cliente>();

    public List<Cliente> getLista() {
        return lista;
    }

    public void setLista(List<Cliente> lista) {
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Cliente r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getCedula_cliente();
            case 1:
                return r.getApellido_cliente();
            case 2:
                return r.getNombre_cliente();
            case 3:
                return r.getTelefono_cliente();
            case 4  :
                return r.getEmail_cliente();
            case 5:
                return r.getCiudad_cliente();
            case 6:
                return r.getArea_cliente();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Cedula";
            case 1:
                return "Apellido";
            case 2:
                return "Nombre";
            case 3:
                return "Telefono";
            case 4: 
                return "Email";
            case 5:
                return "Ciudad";
            case 6:
                return "Direccion";
            default:
                return null;
        }

    }

}
