/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import modelo.Taller;

/**
 *
 * @author Juan Diego
 */
public class TablaTaller extends AbstractTableModel{
    private List<Taller> lista = new ArrayList<Taller>();

    public List<Taller> getLista() {
        return lista;
    }

    public void setLista(List<Taller> lista) {
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Taller r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getRuc_taller();
            case 1:
                return r.getNombre_taller();
            case 2:
                return r.getTelefono_taller();
            case 3:
                return r.getEmail_taller();
            case 4  :
                return r.getCiudad_taller();
            case 5:
                return r.getArea_taller();
            
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Ruc";
            case 1:
                return "Nombre";
            case 2:
                return "Telefono";
            case 3:
                return "Email";
            case 4: 
                return "Ciudad";
            case 5:
                return "Direccion";
            
            default:
                return null;
        }

    }
    
}
